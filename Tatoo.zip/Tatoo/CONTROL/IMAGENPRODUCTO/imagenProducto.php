<?php
session_start();

if (empty($_SESSION['entrar'])) {
    header('Location: ../../index.php');
    die();
}

include('../../conexion.php');

$queryTodosProductos = mysqli_query($conn, "SELECT * FROM productos");
$totalProductos = mysqli_num_rows($queryTodosProductos);


// PAGINACION
$limite = 12;

if (empty($_REQUEST['pagina'])) {
    $pagina = 1;
} else {
    $pagina = $_REQUEST['pagina'];
}

$totalPaginas = ceil($totalProductos / $limite);
$desde = ($pagina - 1) * $limite;

// ELIMINAR
if (isset($_REQUEST['eliminar'])) {
    $id_producto = $_REQUEST['eliminar'];

    $queryEliminar = mysqli_query($conn, "DELETE FROM `productos` WHERE `productos`.`id_producto` = $id_producto ");

    if ($queryEliminar) {
        echo "<script> 
            alert('Eliminado')
            window.location.href= './imagenProducto.php'
         </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../../imagenes/iconos/astronautaConCohete.ico">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">


    <!-- animacion -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <!-- Fuente Dosis -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="../../estiloSpiner.css">
    <link rel="stylesheet" href="../../defecto.css">
    <link rel="stylesheet" href="estiloImagenProducto.css">

    <title>Imagenes Productos</title>
</head>

<body>

    <div id="contenedorLoaderMain" class="desctivadoLoaderMain ">
        <div id="spinerMain" class="desctivadoSpiner "></div>
    </div>


    <img src="../../imagenes/iconos/astronautaConCohete.ico" alt="" class="astronauta">

    <!-- HEADER -->
    <nav class="navbar navbar-expand-lg ">
        <div class="container-fluid">
            <a class="navbar-brand" href="../../index.php">Tattoo Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../admin.php"><img src="../../imagenes/iconos/subir.png" alt="" width="10px"> Imagenes Tattoo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href=""><img src="../../imagenes/iconos/subir.png" alt="" width="10px"> Imagenes Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://squoosh.app" target="_blank">Bajar peso Imagen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../HORARIOSESPECIALIDADES/horariosEspecialidades.php">Horarios/Especialidades</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link salir" href="../cerrarSesion.php">Salir</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <!-- MAIN -->
    <main class="main">

        <div class="contenedorFlex">

            <!-- FORMULARIO -->
            <div class="contenedorFormulario">

                <form id="formulario" class="formulario">

                    <h1>Productos (<?php echo $totalProductos ?>)</h1>
                    <hr>


                    <!-- imagen -->
                    <div class="mb-3">
                        <input class="form-control" id="imagenInput" name="imagenInput" type="file" id="imagenProducto" accept="image/*" required>
                        <img src="" alt="" id="mostrarImagen" width="200px">
                    </div>


                    <!-- nombre -->
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre Producto</label>
                        <input type="text" class="form-control" name="nombre" id="nombre" aria-describedby="emailHelp" required>
                    </div>


                    <!-- descripcion -->
                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea class="form-control" name="descripcion" id="descripcion" cols="30" rows="10" required></textarea>
                    </div>


                    <!-- precio -->
                    <div class="mb-3">
                        <label for="precio" class="form-label">Precio Producto</label>
                        <input type="number" step="0.1" class="form-control" name="precio" id="precio" aria-describedby="emailHelp" required>
                    </div>


                    <!-- categoria -->
                    <div class="mb-3">
                        <label for="categoriaProducto" class="form-label">Categoria producto*</label>


                        <select class="form-select categoriaProducto" name="categoriaProducto" id="categoriaProducto">

                            <?php

                            // CONSULTA CATEGORIA TATUAJES
                            $queryCategoriaProducto = mysqli_query($conn, "SELECT * FROM categoria_producto");

                            while ($recorrerCategoriaProducto = mysqli_fetch_array($queryCategoriaProducto)) {
                            ?>
                                <option value="<?php echo $recorrerCategoriaProducto['id_categoria_producto'] ?>"><?php echo $recorrerCategoriaProducto['nombre'] ?></option>
                            <?php
                            }
                            ?>


                        </select>


                    </div>

                    <div class="mb-3">
                        <input type="submit" class="form-control botonGuardar" value="Guardar" aria-describedby="emailHelp">
                    </div>

                </form>

            </div>


            <!-- CONTENEDOR PRODUCTO -->
            <div class="contenedorProductos" id="contenedorProductos">


                <?php

                $queryMostrarProductos = mysqli_query($conn, "SELECT * FROM productos ORDER BY fecha DESC LIMIT $desde,$limite");

                while ($recorrerDatos = mysqli_fetch_array($queryMostrarProductos)) {
                ?>
                    <div class="cartaProducto" onclick="ulrEditarProducto('<?php echo $recorrerDatos['id_producto'] ?>')">

                        <a class="eliminar" href="?eliminar=<?php echo $recorrerDatos['id_producto'] ?>"><img src="../../imagenes/iconos/close.png" alt="" width="20px"></a>
                        <a class="editar" href="?editar=<?php echo $recorrerDatos['id_producto'] ?>"><img src="../../imagenes/iconos/editar.png" alt="" width="20px"></a>

                        <div class="contenedorImagen"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($recorrerDatos['imagen']) ?>" alt=""></div>

                        <div class="contenedorTexto">
                            <div class="contenedorNombrePrecio">
                                <span><?php echo $recorrerDatos['nombre'] ?></span>
                                <span>$<?php echo $recorrerDatos['precio'] ?></span>
                            </div>
                        </div>
                    </div>

                <?php
                }

                ?>


                <div class="paginacion">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">

                            <?php

                            $i = 0;
                            $limiteFor = 5;
                            for ($i; $i < $totalPaginas; $i++) {
                                if ($limiteFor >= $i) {
                            ?>

                                    <li class="page-item <?php if ($i + 1 == $pagina) echo 'active' ?>"><a class="page-link" href="?pagina=<?php echo $i + 1 ?>"><?php echo $i + 1 ?></a></li>

                            <?php
                                }
                            }

                            ?>


                            <li class="page-item <?php if ($pagina > $limiteFor) echo 'active' ?>"><a class="page-link"><?php echo '-' . $pagina . '-' ?></a></li>


                            <li class="page-item <?php if ($pagina >= $i) echo 'disabled' ?>">
                                <a class="page-link" href="?pagina=<?php echo $pagina + 1 ?>" aria-label="Next">
                                    <span aria-hidden="true" style="color: #424242;">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>



            </div>

        </div>


        </div>


    </main>


    <!-- Js  Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

    <script src="../../evitarReenvioFormulario.js"></script>

    <!-- ALERTA PERSONALIZADA -->
    <script src="../../alertaPersonalizada.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <!-- js animacion -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>


    <script>
        // DATOS GENERALES
        var formulario = document.getElementById('formulario')
        var contenedorProductos = document.getElementById('contenedorProductos')
        var imagenInput = document.getElementById('imagenInput')
        var mostrarImagen = document.getElementById('mostrarImagen')


        // mostrar imagen previa
        imagenInput.addEventListener('change', function(e) {

            let archivoImagen = e.target.files[0]

            let lector = new FileReader()

            lector.onload = function(e) {

                mostrarImagen.src = e.target.result
            }

            lector.readAsDataURL(archivoImagen)
        })

        // mostrar/ocultar spiner
        function mostrarLoader(toggleMostrar) {

            // obtener datos
            var contenedorLoaderMain = document.getElementById('contenedorLoaderMain')
            var spinerMain = document.getElementById('spinerMain')

            if (toggleMostrar == "mostrar") {

                window.scrollTo(0, 0)

                // mostrar el spiner
                contenedorLoaderMain.classList.add('loaderMain')
                spinerMain.classList.add('maze-3')

                // desactivar el scroll
                document.getElementsByTagName("html")[0].style.overflow = "hidden";

            } else {

                window.scrollTo(0, 0)


                // oculatar el spiner
                contenedorLoaderMain.classList.remove('loaderMain')
                spinerMain.classList.remove('maze-3')

                // desactivar el scroll
                document.getElementsByTagName("html")[0].style.overflow = "auto";
            }
        }


        formulario.addEventListener('submit', function(e) {

            e.preventDefault()

            mostrarLoader('mostrar')


            // datos del formulario
            var imagen = document.getElementById('imagenInput').files[0]
            var nombre = document.getElementById('nombre').value
            var descripcion = document.getElementById('descripcion').value
            var precio = document.getElementById('precio').value
            var categoriaProducto = document.getElementById('categoriaProducto').value


            let formdata = new FormData()

            if (imagen != null) {
                formdata.append('imagen', imagen)
            }

            formdata.append('nombre', nombre)
            formdata.append('descripcion', descripcion)
            formdata.append('precio', precio)
            formdata.append('categoriaProducto', categoriaProducto)




            fetch('./insertarImagenProducto.php', {
                    method: 'POST',
                    body: formdata
                })
                .then(res => res.json())
                .then(e => {

                    // IMAGEN MUY PESADA
                    if (e.mensaje == 'Imagen muy pesada') {
                        alertaPersonalizada('ERROR', e.mensaje, 'error', 'Regresar', 'no')
                        return
                    }

                    // DATOS VACIOS
                    if (e.mensaje == 'Datos vacios') {
                        alert(e.mensaje)
                        return
                    }


                    // CORRECTO
                    if (e.mensaje == 'Datos guardados') {

                        alertaPersonalizada('CORRECTO', e.mensaje, 'success', 'Regresar', 'no')


                        contenedorProductos.insertAdjacentHTML('afterbegin', `
                            <div class="cartaProducto" onclick="ulrEditarProducto('${e.id}')">

                                <a class="eliminar" href="?eliminar=${e.id}"><img src="../../imagenes/iconos/close.png" alt="" width="20px"></a>
                                <a class="editar" href="?editar=${e.id}"><img src="../../imagenes/iconos/editar.png" alt="" width="20px"></a>

                                <div class="contenedorImagen"><img src="${mostrarImagen.src}" alt=""></div>

                                <div class="contenedorTexto">
                                    <div class="contenedorNombrePrecio">
                                        <span>${nombre}</span>
                                        <span>$${precio}</span>
                                    </div>
                                </div>
                            </div>
                        `)


                        // LIMPIAR FORMULARIO
                        document.getElementById('imagenInput').value = null
                        document.getElementById('nombre').value = ''
                        document.getElementById('descripcion').value = ''
                        document.getElementById('precio').value = ''
                    }
                })
                .finally(e => {

                    // ocultar Loader
                    mostrarLoader('ocultar')

                })
        })


        // funcion href llevar a editar producto
        function ulrEditarProducto(id) {
            window.location.href = `../../DETALLE/DETALLEPRODUCTO/detalleProducto.php?producto=${id}`
        }
    </script>
</body>

</html>