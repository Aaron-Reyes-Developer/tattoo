<?php

session_start();

if (!isset($_SESSION['entrar'])) {
    header('Location: ../index.php');
    die();
}



include('../conexion.php');


// EDITAR
if (isset($_REQUEST['editar'])) {

    $editar = $_REQUEST['editar'];

    $queryDatosEditar = mysqli_query($conn, "SELECT * FROM datos_tattoo WHERE id_datos_tattoo = $editar");
    $recorrerEditar = mysqli_fetch_array($queryDatosEditar);
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../imagenes/iconos/astronautaConCohete.ico">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">


    <!-- animacion -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <!-- Fuente Dosis -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../estiloSpiner.css">
    <link rel="stylesheet" href="../defecto.css">
    <link rel="stylesheet" href="./estiloEditar.css">
    <title>Editar</title>
</head>

<body>

    <div class="desctivadoLoaderMain" id="contenedorLoaderMain">
        <div id="spinerMain" class="desctivadoSpiner"></div>
    </div>


    <main class="main">

        <div class="contenedorImagen">
            <img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($recorrerEditar['imagen']) ?>" alt="">
        </div>


        <div class="contenedorFormulario">

            <form action="" method="post" class="formulario" id="formulario">

                <span class="sizeImagen"><?php echo $recorrerEditar['peso_imagen'] ?> kb</span>

                <h1>Editar Tatuaje</h1>
                <hr>

                <div class="contenedorDatoVacios" id="contenedorDatoVacios"> </div>


                <!-- imagen -->
                <div class="mb-3">

                    <label for="imagen" class="form-label">Subir Imagen (jpg/png/webp) <br> <span class="menajeNoEditarImagen">(no subir imagen si no se quiere editar)</span> </label>
                    <input type="file" name="imagen" id="imagen" class="form-control" accept="image/*">

                </div>


                <!-- titulo -->
                <div class="mb-3">
                    <label for="tituloTattoo" class="form-label">Titulo del Tattoo</label>
                    <input class="form-control" name="tituloTattoo" id="tituloTattoo" type="text" value="<?php echo $recorrerEditar['nombre'] ?>">
                </div>


                <!-- descripcion -->
                <div class="form-floating mb-3">
                    <textarea class="form-control" name="descripcionTattoo" id="descripcionTattoo" placeholder="Leave a comment here" style="height: 100px"> <?php echo $recorrerEditar['detalle'] ?> </textarea>
                    <label for="descripcionTattoo" class="labelDescripcion">Descripción de el tattoo</label>
                </div>


                <!-- sesiones -->
                <div class="mb-3">
                    <label for="sesionesTattoo" class="form-label">Total de Sesiones</label>
                    <input class="form-control" name="sesionesTattoo" id="sesionesTattoo" type="number" value="<?php echo $recorrerEditar['sesiones'] ?>">
                </div>


                <!-- horas por sesiones -->
                <div class="mb-3">
                    <label for="horasTattoo" class="form-label">Horas por Sesiones</label>
                    <input class="form-control" name="horasTattoo" id="horasTattoo" type="number" value="<?php echo $recorrerEditar['horas_sesiones'] ?>">
                </div>


                <!-- precio -->
                <div class="mb-3">
                    <label for="precioTattoo" class="form-label">Precio aproximado</label>
                    <input class="form-control" name="precioTattoo" id="precioTattoo" type="number" step="0.01" value="<?php echo $recorrerEditar['precio_aproximado'] ?>">
                </div>


                <!-- checkbox -->
                <div class="form-check mb-3">
                    <label class="form-check-label" for="checkbox"> Poner como cabecera </label>
                    <input class="form-check-input" name="checkbox" id="checkbox" type="checkbox" <?php if ($recorrerEditar['en_cabecera'] == 1) echo 'checked' ?>>
                </div>




                <div class="mb-3">
                    <input class="form-control botonEditar" name="editar" type="submit" value="Editar">
                </div>
            </form>

        </div>

    </main>


    <!-- ALERTA PERSONALIZADA -->
    <script src="../alertaPersonalizada.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>



    <script>
        // mostrar/ocultar spiner
        function mostrarLoader(toggleMostrar) {

            // obtener datos
            var contenedorLoaderMain = document.getElementById('contenedorLoaderMain')
            var spinerMain = document.getElementById('spinerMain')

            if (toggleMostrar == "mostrar") {

                window.scrollTo(0, 0)

                // mostrar el spiner
                contenedorLoaderMain.classList.add('loaderMain')
                spinerMain.classList.add('maze-3')

                // desactivar el scroll
                document.getElementsByTagName("html")[0].style.overflow = "hidden";

            } else {

                window.scrollTo(0, 0)


                // oculatar el spiner
                contenedorLoaderMain.classList.remove('loaderMain')
                spinerMain.classList.remove('maze-3')

                // desactivar el scroll
                document.getElementsByTagName("html")[0].style.overflow = "auto";
            }
        }


        // obtener datos 
        var id_tattoo = <?php echo $recorrerEditar['id_datos_tattoo'] ?>;
        var formulario = document.getElementById('formulario')
        var contenedorDatoVacios = document.getElementById('contenedorDatoVacios')

        formulario.addEventListener('submit', function(e) {

            e.preventDefault()

            // mostrar el loader
            mostrarLoader('mostrar')

            var tituloTattoo = document.getElementById('tituloTattoo').value
            var descripcionTattoo = document.getElementById('descripcionTattoo').value
            var sesionesTattoo = document.getElementById('sesionesTattoo').value
            var horasTattoo = document.getElementById('horasTattoo').value
            var precioTattoo = document.getElementById('precioTattoo').value
            var checkboxInput = document.getElementById('checkbox') //este valor no se debe de enviar al php
            var checkbox = checkboxInput.checked ? 1 : 0

            var imagenInput = document.getElementById('imagen').files[0]



            let formdata = new FormData()

            formdata.append('id', id_tattoo)
            formdata.append('tituloTattoo', tituloTattoo)
            formdata.append('descripcionTattoo', descripcionTattoo)
            formdata.append('sesionesTattoo', sesionesTattoo)
            formdata.append('horasTattoo', horasTattoo)
            formdata.append('precioTattoo', precioTattoo)
            formdata.append('cheked', checkbox)

            if (imagenInput != undefined) {
                formdata.append('imagen', imagenInput)
            }

            fetch('./insertarTatuajeEditado.php', {
                    method: 'POST',
                    body: formdata
                })
                .then(res => res.json())
                .then(e => {

                    // mensaje datos vacios
                    if (e.mensaje == 'Datos vacios') {

                        contenedorDatoVacios.innerHTML = `
                            <div class="alert alert-danger" role="alert">
                                Datos Vacios
                            </div>
                        `
                        return
                    }


                    // si todo sale bien
                    if (e.mensaje == 'Editados Correctamente') {

                        alertaPersonalizada('CORRECTO', 'Editado Correctamente', 'success', 'Regresar', 'si')

                    } else if (e.mensaje == 'Imagen Pesada') {

                        alertaPersonalizada('ERROR', 'Imagen muy pesada', 'error', 'Regresar', 'no')
                        return
                    }


                })
                .catch(error => console.log('ERRROOOORRR', error))
                .finally(_ => {
                    mostrarLoader('ocultar')
                })
        })
    </script>
</body>

</html>