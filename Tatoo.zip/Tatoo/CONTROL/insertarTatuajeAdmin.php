<?php

include('../conexion.php');
session_start();
if (empty($_SESSION['entrar'])) {
    header('Location: ../index.php');
    die();
}



//datos desde el formulario
if (
    $_POST['tituloTattoo'] == "" ||
    $_POST['descripcionTattoo'] == "" ||
    $_POST['sesionesTattoo'] == "" ||
    $_POST['horasTattoo'] == "" ||
    $_POST['precioTattoo'] == ""
) {
    $menaje = array('mensaje' => 'Datos vacios');
    echo json_encode($menaje);
    die();
}


// // DATOS
$tituloTattoo = $_POST['tituloTattoo'];
$descripcionTattoo = $_POST['descripcionTattoo'];
$sesionesTattoo = $_POST['sesionesTattoo'];
$horasTattoo = $_POST['horasTattoo'];
$precioTattoo = $_POST['precioTattoo'];
$categoriaTataje = $_POST['categoriaTatuaje'];
$en_cabecera = $_POST['checkbox'];
$imagenSinFiltro = $_FILES['imagenInput'];
$nombreImagen = $imagenSinFiltro['name'];
$rutaTemporalImagen = $imagenSinFiltro['tmp_name'];
$sizeImagenByte = $imagenSinFiltro['size'];
$datosImagen = file_get_contents($rutaTemporalImagen);
$imagenEscapado = $conn->real_escape_string($datosImagen);
$sizeImagenKb  = $sizeImagenByte / 1000;

// si el tamaño de la imagen supera 1megabyte
if ($sizeImagenKb >= 1000) {
    $menaje = array('mensaje' => 'La imagen es muy pesada');
    echo json_encode($menaje);
    die();
}


// query ingresar datos
$queryIngresarDatos = mysqli_query($conn, "CALL insertarTatuaje('$imagenEscapado', $sizeImagenKb , '$tituloTattoo' , '$descripcionTattoo' , $sesionesTattoo , $horasTattoo , $precioTattoo , $en_cabecera , $categoriaTataje)");
while (mysqli_next_result($conn)) {;
}




$queryCosnulta = mysqli_query($conn, "SELECT * FROM datos_tattoo WHERE nombre = '$tituloTattoo' AND detalle = '$descripcionTattoo' ");
$recorrerDatos = mysqli_fetch_array($queryCosnulta);



if ($queryIngresarDatos) {

    $menaje = array('mensaje' => 'Guardado', 'id' => $recorrerDatos['id_datos_tattoo'], 'size' => $recorrerDatos['peso_imagen']);
    echo json_encode($menaje);
} else {

    $menaje = array('mensaje' => 'Error db');
    echo json_encode($menaje);
}
