<?php

$server = "localhost";
$usuario = "root";
$contra = "";
$bd = "tattoobd";

$conn = mysqli_connect($server, $usuario, $contra, $bd);
