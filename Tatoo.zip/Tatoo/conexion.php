<?php

$server = "localhost";
$usuario = "root";
$contra = "";
$bd = "tatuajebd";

$conn = mysqli_connect($server, $usuario, $contra, $bd);
