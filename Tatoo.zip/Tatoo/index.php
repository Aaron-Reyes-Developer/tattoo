<?php
include('./conexion.php');

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fuente Dosis -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">


    <!-- animacion -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <link rel="stylesheet" href="estiloIndex.css">
    <link rel="stylesheet" href="defecto.css">
    <link rel="stylesheet" href="estiloHeader.css">

    <title>Tattol Smoking Shop</title>
</head>

<body>

    <div class="page">


        <header class="header" id="header">

            <div class="contenedorLogo"> <a href="#"> <img src="./imagenes/logoTattoo.webp" alt=""> </a> </div>

            <nav class="nav" id="nav">
                <ul>
                    <li id="liNav"><a href="#">Inicio</a> </li>
                    <li id="liNav" id="nosotrps"><a href="#sobreNosotros">Nosotros</a> </li>
                    <li id="liNav"><a href="">Tienda</a> </li>
                    <li id="liNav"><a href="#horarios">Citas</a> </li>
                    <li id="liNav"><a href="#contacto">Contacto</a> </li>
                    <li id="cotizar liNav">
                        <a href="https://wa.me/5930987270403?text=Deseo cotizar un tatuaje en su estudio" target="_blank">
                            Cotizar
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="contenedorBar" id="bar" onclick="barFuncion()">
                <img src="./imagenes/iconos/bar.png" alt="" id="imagenBar">
                <img src="./imagenes/iconos/close.png" alt="" id="imagenBarClose" style="display: none;">
            </div>

        </header>

        <main>

            <div class="contenedorIrArriba" id="flechaIrArriba">
                <img src="./imagenes/iconos/flechaArriba.png" alt="">
            </div>


            <!-- PORTADA -->
            <div class="contenedorPortada" data-aos="fade-up">

                <h1> TATTOOL ESTUDIO DE ARTE </h1>
                <span>
                    Empresa de tatuajes experta en el <b> <strong>Arte</strong> <strong>Corporal</strong> </b>
                </span>

                <div class="rombo" id="rombo" onclick="irAbajo('portafolio')"></div>

            </div>


            <!-- PORTAFOLIO -->
            <section class="seccionPortafolio container" id="portafolio">

                <div class="contenedorTituloPortafolio">
                    <h2>PORTAFOLIO</h2>
                    <a href="./VERTODO/verTodo.php">Ver todo...</a>
                </div>

                <div class="grid">

                    <?php
                    // mostrar fotos
                    $queryMostrarFotos = mysqli_query($conn, "SELECT * FROM datos_tattoo WHERE en_cabecera = 1 ORDER BY id_datos_tattoo DESC LIMIT 8 ");

                    // mostrar las fotos
                    while ($recorrerFotos = mysqli_fetch_array($queryMostrarFotos)) {
                    ?>

                        <div class="cartaPortafolio" data-aos="fade-up">
                            <a href="./DETALLE/detalleTattoo.php?tattoo=<?php echo $recorrerFotos['id_datos_tattoo'] ?>">
                                <img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($recorrerFotos['imagen']) ?>" alt="<?php echo $recorrerFotos['nombre'] ?>">
                            </a>
                        </div>
                    <?php
                    }

                    ?>





                </div>
            </section>


            <!-- SOBRE NOSOTROS -->
            <section class="seccionSobreNosotros container" id="sobreNosotros" data-aos="fade-up">

                <h2>SOBRE NOSOTROS</h2>

                <div class="contenedorTextoMaps">


                    <div class="contenedorTexto">
                        <p>
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores nam nulla assumenda, iure
                            soluta aspernatur, ipsam facere, expedita reprehenderit ratione omnis labore quia? Atque eum
                            ipsam vitae molestiae necessitatibus aut!
                        </p>

                        <button>Agendar Cita</button>
                    </div>


                    <div class="contenedorMaps">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15957.103662205067!2d-80.7413227!3d-0.9447736!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x902be130a753ec2b%3A0x321134009b264462!2sTattool%20Smoking%20Shop!5e0!3m2!1ses!2sec!4v1687829827629!5m2!1ses!2sec" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>



                </div>


            </section>


            <!-- ESPECIALIDADES -->
            <section class="seccionEspecialidades" id="especialidades" data-aos="fade-up">

                <div class="contenedorEspecialidades container">

                    <h2>ESPECIALIDADES</h2>

                    <div class="subContenedorEspecialidades">


                        <div class="contenedorIconosEspecialidades">
                            <img src="./imagenes/maquina-de-tatuar.webp" alt="">
                            <img src="./imagenes/perforacion.webp" alt="">
                            <img src="./imagenes/tienda.webp" alt="">
                        </div>


                        <div class="conetenedorListaEspecialidades">
                            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Labore, laborum.</p>
                            <ul>
                                <li><strong>Tatuajes Personalizados</strong></li>
                                <li><strong>Perforaciones</strong></li>
                                <li><strong>Tienda Fisica</strong></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </section>


            <!-- HORARIOS DE ATENCION -->
            <section class="seccionHorario container" id="horarios" data-aos="fade-up">

                <h2>HORARIOS DE ATENCIÓN</h2>

                <div class="subcontenedorHorarios">
                    <ul>
                        <li>Lunes: 10:00 - 21:00 </li>
                        <li>Martes: 10:00 - 21:00 </li>
                        <li>Miercoles: 10:00 - 21:00 </li>
                        <li>Jueves: 10:00 - 21:00 </li>
                        <li>Viernes: 10:00 - 21:00 </li>
                        <li>Sabado: 10:00 - 21:00 </li>
                        <li style="color: rgb(255, 88, 88);">Domingo: No Atiende</li>
                    </ul>



                    <div class="contenedorAgendarCita">
                        <a href="https://wa.me/5930987270403?text=Deseo cotizar un tatuaje en su estudio" target="_blank">Cotizar</a>
                    </div>
                </div>
            </section>


            <!-- SECCION CONTACTO -->
            <section class="seccionContacto container" id="contacto" data-aos="fade-up">

                <h2>CONTÁCTANOS</h2>


                <div class="contenedorContactanos">


                    <div class="contenedorFormulario">


                        <form action="" method="post" class="formulario needs-validation" novalidate>

                            <h3>Contáctanos</h3>

                            <div class="form-floating mb-3 has-validation">
                                <input type="text" name="nombre" class="form-control" id="floatingInput" placeholder="Nombre y Apellido" required>
                                <label for="floatingInput">Nombre y Apellido</label>

                                <div class="invalid-feedback">
                                    Ingrese un Nombre y Apellido.
                                </div>
                            </div>



                            <div class="form-floating mb-3">
                                <input type="email" name="correo" class="form-control" id="floatingInput" placeholder="correo@ejemplo.com" required>
                                <label for="floatingInput">Correo Electronico</label>

                                <div class="invalid-feedback">
                                    Ingrese un correo valido.
                                </div>
                            </div>

                            <div class="form-floating">
                                <textarea class="form-control" placeholder="Mensaje" id="floatingTextarea2" style="height: 100px" required></textarea>
                                <label for="floatingTextarea2">Mensaje</label>

                                <div class="invalid-feedback">
                                    Ingrese un mensaje.
                                </div>
                            </div>

                            <input type="submit" value="Enviar" class="botonEnviar">
                        </form>

                    </div>




                    <div class="contenedorImagenFormulario">
                        <img src="./imagenes/contacto.webp" alt="">
                    </div>
                </div>


            </section>


            <!-- FOOTER -->
            <div class="contenedorMainFooter" data-aos="fade-up">

                <div style="height: 150px; overflow: hidden;">
                    <svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;">
                        <path d="M-84.08,154.45 C149.99,150.00 467.27,63.66 515.79,169.25 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #303030;"></path>
                    </svg>
                </div>


                <footer class="footer" id="footer">

                    <div class="contenedorFooter">

                        <div class="contenedorLogoFooter">
                            <img src="./imagenes/logoTattoo.webp" alt="">
                            <span>TATTOOS SMOKING</span>
                        </div>

                        <div class="contenedorSobreNosotrosFooter sobreNosotrosFooter">
                            <span class="textoSobreNosotros">Sobre Nosotros</span>
                            <ul>
                                <li><a href="#">Inicio</a></li>
                                <li><a href="#portafolio">Portafolio</a></li>
                                <li><a href="#sobreNosotros">Nosotros</a></li>
                                <li><a href="">Tienda</a></li>
                                <li><a href="#horarios">Citas</a></li>
                            </ul>
                        </div>

                        <div class="contenedorSobreNosotrosFooter contenedorRedesFooter">

                            <span>Redes</span>

                            <ul>


                                <li>
                                    <a href="https://www.facebook.com/Tattoolestudiodearte/" target="_blank">
                                        Faceboock
                                        <img src="./imagenes/iconos/facebook.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a href="https://wa.me/5930987270403?text=Deseo obtner más informacion sobre su estudio" target="_blank">
                                        Whatsapp
                                        <img src="./imagenes/iconos/whatsapp.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a href="">
                                        Instagram
                                        <img src="./imagenes/iconos/instagram.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a href="">
                                        Youtube
                                        <img src="./imagenes/iconos/youtube.png" alt="">
                                    </a>
                                </li>

                            </ul>

                        </div>
                    </div>


                    <hr>

                    <div class="contenedorMiMarca">
                        ©
                        <b id="fechaMiMarca"></b>
                        &nbsp By: &nbsp Aaron Reyes &nbsp -> &nbsp
                        <a href="#"> www.aaronreyes.com </a>
                        <img src="./imagenes/iconos/estrella1.png" alt="">
                    </div>

                </footer>

            </div>




        </main>



    </div>




    <!-- Js  Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

    <script src="./validacionFormularioBoostrap.js"></script>


    <!-- js animacion -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>

    <script src="logicaHeader.js"></script>


    <script>
        // IR A #
        const irAbajo = e => {
            window.location.href = `#${e}`
        }


        // FECHA ACTUAL MI MARCA
        let fechaMiMarca = document.getElementById('fechaMiMarca')
        let year = new Date()
        fechaMiMarca.innerHTML = year.getFullYear()
    </script>
</body>

</html>