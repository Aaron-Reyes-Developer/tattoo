<?php
include('./conexion.php');

?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0C0C0C">
    <!-- Fuente Dosis -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">


    <!-- animacion -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <link rel="stylesheet" href="estiloIndex.css">
    <link rel="stylesheet" href="defecto.css">
    <link rel="stylesheet" href="estiloHeader.css">

    <title>Tattol Smoking Shop</title>
</head>

<body>

    <div class="page">


        <header class="header" id="header">

            <div class="contenedorLogo" id="contenedorLogo"> <a href="#"> <img src="./imagenes/logoTattoo.webp" alt=""> </a> </div>

            <nav class="nav" id="nav">
                <ul>
                    <li id="liNav" class="active"><a href="#">Inicio</a> </li>
                    <li id="liNav" id="nosotrps"><a href="#sobreNosotros">Nosotros</a> </li>
                    <li id="liNav"><a href="./VERTODO/VERTODOPRODUCTO/vertodoProducto.php">Tienda</a> </li>
                    <li id="liNav"><a href="#horarios">Citas</a> </li>
                    <li id="liNav"><a href="#contacto">Contacto</a> </li>
                    <li id="cotizar liNav">
                        <a href="https://wa.me/5930987270403?text=Deseo cotizar un tatuaje en su estudio" target="_blank">
                            Cotizar
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="contenedorBar" id="bar" onclick="barFuncion()">
                <img src="./imagenes/iconos/bar.png" alt="" id="imagenBar">
                <img src="./imagenes/iconos/close.png" alt="" id="imagenBarClose" style="display: none;">
            </div>

        </header>

        <main>

            <div class="contenedorIrArriba" id="flechaIrArriba">
                <img src="./imagenes/iconos/flechaArriba.png" alt="">
            </div>


            <!-- PORTADA -->
            <div class="contenedorPortada" data-aos="fade-up">

                <h1> TATTOOL ESTUDIO DE ARTE </h1>
                <span>
                    Empresa de tatuajes experta en el <b> <strong>Arte</strong> <strong>Corporal</strong> </b>
                </span>

                <div class="rombo" id="rombo" onclick="irAbajo('portafolio')"></div>

            </div>


            <!-- PORTAFOLIO -->
            <section class="seccionPortafolio container" id="portafolio">

                <div class="contenedorTituloPortafolio">
                    <h2>PORTAFOLIO</h2>
                    <a href="./VERTODO/verTodo.php">Ver todo...</a>
                </div>

                <div class="grid">

                    <?php
                    // mostrar fotos
                    $queryMostrarFotos = mysqli_query($conn, "SELECT * FROM datos_tattoo WHERE en_cabecera = 1 ORDER BY id_datos_tattoo DESC LIMIT 8 ");

                    // mostrar las fotos
                    while ($recorrerFotos = mysqli_fetch_array($queryMostrarFotos)) {
                    ?>

                        <div class="cartaPortafolio" data-aos="fade-up">
                            <a href="./DETALLE/detalleTattoo.php?tattoo=<?php echo $recorrerFotos['id_datos_tattoo'] ?>">
                                <img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($recorrerFotos['imagen']) ?>" alt="<?php echo $recorrerFotos['nombre'] ?>">
                            </a>
                        </div>
                    <?php
                    }

                    ?>





                </div>
            </section>


            <!-- SOBRE NOSOTROS -->
            <section class="seccionSobreNosotros container" id="sobreNosotros" data-aos="fade-up">

                <h2>SOBRE NOSOTROS</h2>

                <div class="contenedorTextoMaps">


                    <div class="contenedorTexto">
                        <p>
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores nam nulla assumenda, iure
                            soluta aspernatur, ipsam facere, expedita reprehenderit ratione omnis labore quia? Atque eum
                            ipsam vitae molestiae necessitatibus aut!
                        </p>

                        <button>Agendar Cita</button>
                    </div>


                    <div class="contenedorMaps">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15957.103662205067!2d-80.7413227!3d-0.9447736!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x902be130a753ec2b%3A0x321134009b264462!2sTattool%20Smoking%20Shop!5e0!3m2!1ses!2sec!4v1687829827629!5m2!1ses!2sec" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>



                </div>


            </section>


            <!-- ESPECIALIDADES -->
            <section class="seccionEspecialidades" id="especialidades" data-aos="fade-up">

                <div class="contenedorEspecialidades container">

                    <h2>ESPECIALIDADES</h2>

                    <div class="subContenedorEspecialidades">


                        <div class="contenedorIconosEspecialidades">
                            <img src="./imagenes/maquina-de-tatuar.webp" alt="">
                            <img src="./imagenes/perforacion.webp" alt="">
                            <img src="./imagenes/tienda.webp" alt="">
                        </div>


                        <div class="conetenedorListaEspecialidades">
                            <?php
                            $queryEspecialidades = mysqli_query($conn, "SELECT * FROM especialidad");
                            $recorrerEspecialidad = mysqli_fetch_array($queryEspecialidades);
                            ?>
                            <p><?php echo $recorrerEspecialidad['parrafo'] ?></p>
                            <ul>
                                <li><strong><?php echo $recorrerEspecialidad['especialidad_1'] ?></strong></li>
                                <li><strong><?php echo $recorrerEspecialidad['especialidad_2'] ?></strong></li>
                                <li><strong><?php echo $recorrerEspecialidad['especialidad_3'] ?></strong></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </section>


            <!-- HORARIOS DE ATENCION -->
            <section class="seccionHorario container" id="horarios" data-aos="fade-up">

                <h2>HORARIOS DE ATENCIÓN</h2>

                <div class="subcontenedorHorarios">
                    <?php
                    $queryHorario = mysqli_query($conn, "SELECT * FROM horario");
                    $recorrerHorario = mysqli_fetch_array($queryHorario);
                    ?>

                    <ul>
                        <li>Lunes: <?php echo $recorrerHorario['lunes'] ?> </li>
                        <li>Martes: <?php echo $recorrerHorario['martes'] ?> </li>
                        <li>Miercoles: <?php echo $recorrerHorario['miercoles'] ?> </li>
                        <li>Jueves: <?php echo $recorrerHorario['jueves'] ?> </li>
                        <li>Viernes: <?php echo $recorrerHorario['viernes'] ?> </li>
                        <li>Sabado: <?php echo $recorrerHorario['sabado'] ?> </li>
                        <li style="color: rgb(255, 88, 88);"><?php echo $recorrerHorario['domingo'] ?></li>
                    </ul>



                    <div class="contenedorAgendarCita">
                        <a href="https://wa.me/5930987270403?text=Deseo cotizar un tatuaje en su estudio" target="_blank">Cotizar <img src="./imagenes/iconos/whatsappAdquirir.png" width="15px" alt=""></a>
                    </div>
                </div>
            </section>


            <!-- PRODUCTOS -->
            <section class="seccionProductos container" data-aos="fade-up">

                <div class="contenTituloProducto">
                    <h2>PRODUCTOS</h2>
                    <a href="./VERTODO/VERTODOPRODUCTO/vertodoProducto.php">Ver todo...</a>
                </div>


                <div class="contenedorProductos">

                    <?php
                    $queryProducto = mysqli_query($conn, "SELECT * FROM productos ORDER BY fecha DESC LIMIT 4");

                    while ($recorrerProductos = mysqli_fetch_array($queryProducto)) {

                    ?>
                        <div class="cartaProducto">

                            <a href="./DETALLE/DETALLEPRODUCTO/detalleProducto.php?producto=<?php echo $recorrerProductos['id_producto'] ?>" class="contenedorImagenProducto"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($recorrerProductos['imagen']) ?>" alt=""></a>

                            <div class="contenedorTextoProducto">
                                <div class="contenedorTituloProducto">
                                    <span><?php echo $recorrerProductos['nombre'] ?></span>
                                    <span class="precio">$<?php echo $recorrerProductos['precio'] ?></span>
                                </div>
                                <button onclick="enviarWhatsapp('<?php echo $recorrerProductos['nombre'] ?>','<?php echo $recorrerProductos['precio'] ?>')">Adquirir <img src="./imagenes/iconos/whatsappAdquirir.png" alt="" width="18px"></button>
                            </div>
                        </div>

                    <?php

                    }

                    ?>

                </div>


            </section>


            <!-- ESTADISTICAS -->
            <section class="seccionEstadistica ">

                <div class="contenedorEstadistica container">

                    <div class="anosExperiencia  subContenedorEstadistica">
                        <span class="numeroExperiencia numeroEstadistica">5</span>
                        <span class="textoExperiencia textoEstadistica">Años de experiencia</span>
                    </div>


                    <div class="clientesAtendido subContenedorEstadistica">
                        <span class="numeroAtendido numeroEstadistica">>50</span>
                        <span class="textoAtendido textoEstadistica">Clientes atendidos </span>
                    </div>


                    <div class="colaboradores subContenedorEstadistica">
                        <span class="numeroColaboradores numeroEstadistica">6</span>
                        <span class="textoColaboradores textoEstadistica">Colaboradores</span>
                    </div>
                </div>

            </section>


            <!-- COLABORADORES -->
            <section class="seccionColaboradores container">


                <h2>COLABORADORES</h2>

                <div class="contenedorColaboradorGrid">


                    <div class="colaborador">
                        <div class="contenedorImagenColaborador"><img src="https://imagenes.elpais.com/resizer/6zpje8PQ5sGMj4kx-45mAMrkU2c=/1200x0/cloudfront-eu-central-1.images.arcpublishing.com/prisa/I4PZI3PSQBEX7JBAKXFS35BJZE.jpg" alt=""></div>
                        <hr>
                        <span class="nombreColaborador">Aaron Reyes</span>
                        <p class="fraseColaborador">
                            Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Voluptatibus eaque,
                            sequi sit esse earum facere.
                        </p>
                    </div>


                    <div class="colaborador">
                        <div class="contenedorImagenColaborador"><img src="https://previews.123rf.com/images/avistock/avistock2103/avistock210300162/166079582-maestro-de-tatuajes-masculinos-sonriendo-tatuando-a-una-clienta-m%C3%A1quina-de-tatuaje-y-l%C3%A1mpara.jpg" alt=""></div>
                        <hr>
                        <span class="nombreColaborador">Aaron Reyes</span>
                        <p class="fraseColaborador">
                            Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Voluptatibus eaque,
                            sequi sit esse earum facere.
                        </p>
                    </div>


                    <div class="colaborador">
                        <div class="contenedorImagenColaborador"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgiEQ6D0hxYbleNQKYxlb-lBdJIYbWNKyOQA&usqp=CAU" alt=""></div>
                        <hr>
                        <span class="nombreColaborador">Aaron Reyes</span>
                        <p class="fraseColaborador">
                            Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Voluptatibus eaque,
                            sequi sit esse earum facere.
                        </p>
                    </div>
                </div>

            </section>


            <!-- RESEÑAS -->
            <section class="seccionResena container">

                <h2>RESEÑAS</h2>
                <span class="textoAlternativo">( Comentarios tomados de 'Google maps' )</span>


                <div class="contenedorResenas">

                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/AD_cMMS3orXlPxMFkHYxdRknh02iyx4YtUSOzcSPacpF-38Wm08=w60-h60-p-rp-mo-ba3-br100" alt=""> </div>
                            <span class="nombre">Sleider- Parrales</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>Accesorios de smoke , gran variedad, excelente atención, buen ambiente y musica.</span>
                        </div>

                        <a href="https://goo.gl/maps/9sMU6Hk6RARbchw97" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/AD_cMMRf6MKrd_nOTlElYeNNxnQ7OWsnt4lhOTKlT7km9ZgLZQ=w60-h60-p-rp-mo-ba3-br100" alt=""> </div>
                            <span class="nombre">Juan Diego Chavez Mero</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>Súper cómodo y profesional, con buenos precios.</span>
                        </div>

                        <a href="https://goo.gl/maps/GiuHoDNWpas6eZJV7" class="verResena" target="_blank">Ver reseña...</a>

                    </div>

                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/AD_cMMQvUvbKkjc2QDb1i_M6fnnpMpS4GB1DQokKoxHTvNo17eaX=w60-h60-p-rp-mo-br100" alt=""> </div>
                            <span class="nombre">Camila Macias Alava</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>Local muy cómodo, seguro y aseado.</span>
                        </div>

                        <a href="https://goo.gl/maps/kMK87NvbrEtmLX6y9" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a/AAcHTtdf1DujhqTHA7vD_2bkhYewaZ7fqn1dqrNLEy31k0Sx=w60-h60-p-rp-mo-br100" alt=""> </div>
                            <span class="nombre">Hugo Zambrano</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>
                                Son los mejores.. Son pocos como ellos q pueden darte la coonfianza,
                                sus trabajos garantizados llenando las exigencias del tatuaje moderno
                                en todos los estilos.. Gracias por los tatuajes hecho en tu estudio
                                sabía q solo allí podía quedar elegante.
                            </span>
                        </div>

                        <a href="https://goo.gl/maps/PnJekri9FBpZXg4D8" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/AD_cMMR_46plDE3jbpmm6as6MuM3w0NxcX1J27U5y43ZZVcMyw=w36-h36-p-rp-mo-ba2-br100" alt=""> </div>
                            <span class="nombre">Andres Cantos</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>
                                Excelente atención, Muy buenos precios
                                Personas muy profesionales que saben del tema atendiendo!
                                Recomendadisimo para tatuarse, y para hacer compras de artículos!
                            </span>
                        </div>

                        <a href="https://goo.gl/maps/eCxUj4K1SrT3ZaeY6" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/AD_cMMRXDpB7MV-ar1GqkdVRku48I6_l25wOV0f4dxlJK1nyuXhH=w36-h36-p-rp-mo-ba5-br100" alt=""> </div>
                            <span class="nombre">Christian Spana</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>El lugar y la atención excelente. Ulises es un gran artista.</span>
                        </div>

                        <a href="https://goo.gl/maps/9sMU6Hk6RARbchw97" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                </div>


            </section>


            <!-- FOTOS LOCAL -->
            <section class="seccionFotosLocal container" id="seccionFotosLocal">


                <div class="modalDesactivado" id="contenedorModal">
                    <span onclick="cerrarModal()">&times;</span>
                    <img src="https://media.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs" id="modalImagen" alt="">

                </div>


                <h2>LOCAL</h2>


                <div class="gridLocal">

                    <div class="div1 contenedorImagenLocal" id="div1" onclick="mostrarImagen('div1')"></div>
                    <div class="div2 contenedorImagenLocal" id="div2" onclick="mostrarImagen('div2')"></div>
                    <div class="div3 contenedorImagenLocal" id="div3" onclick="mostrarImagen('div3')"></div>
                    <div class="div4 contenedorImagenLocal" id="div4" onclick="mostrarImagen('div4')"></div>
                    <div class="div5 contenedorImagenLocal" id="div5" onclick="mostrarImagen('div5')"></div>
                    <div class="div6 contenedorImagenLocal" id="div6" onclick="mostrarImagen('div6')"></div>
                    <div class="div7 contenedorImagenLocal" id="div7" onclick="mostrarImagen('div7')"></div>
                    <div class="div8 contenedorImagenLocal" id="div8" onclick="mostrarImagen('div8')"></div>

                </div>


            </section>

            <!-- SECCION CONTACTO -->
            <section class="seccionContacto container" id="contacto" data-aos="fade-up">

                <h2>CONTÁCTANOS</h2>


                <div class="contenedorContactanos">


                    <div class="contenedorFormulario">


                        <form action="" method="post" class="formulario needs-validation" novalidate>

                            <h3>Contáctanos</h3>

                            <div class="form-floating mb-3 has-validation">
                                <input type="text" name="nombre" class="form-control" id="floatingInput" placeholder="Nombre y Apellido" required>
                                <label for="floatingInput">Nombre y Apellido</label>

                                <div class="invalid-feedback">
                                    Ingrese un Nombre y Apellido.
                                </div>
                            </div>



                            <div class="form-floating mb-3">
                                <input type="email" name="correo" class="form-control" id="floatingInput" placeholder="correo@ejemplo.com" required>
                                <label for="floatingInput">Correo Electronico</label>

                                <div class="invalid-feedback">
                                    Ingrese un correo valido.
                                </div>
                            </div>

                            <div class="form-floating">
                                <textarea class="form-control" placeholder="Mensaje" id="floatingTextarea2" style="height: 100px" required></textarea>
                                <label for="floatingTextarea2">Mensaje</label>

                                <div class="invalid-feedback">
                                    Ingrese un mensaje.
                                </div>
                            </div>

                            <input type="submit" value="Enviar" class="botonEnviar">
                        </form>

                    </div>




                    <div class="contenedorImagenFormulario">
                        <img src="./imagenes/contacto.webp" alt="">
                    </div>
                </div>


            </section>


            <!-- FOOTER -->
            <div class="contenedorMainFooter" data-aos="fade-up">

                <div style="height: 150px; overflow: hidden;">
                    <svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;">
                        <path d="M-84.08,154.45 C149.99,150.00 467.27,63.66 515.79,169.25 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #303030;"></path>
                    </svg>
                </div>


                <footer class="footer" id="footer">

                    <div class="contenedorFooter">

                        <div class="contenedorLogoFooter">
                            <img src="./imagenes/logoTattoo.webp" alt="">
                            <span>TATTOOS SMOKING</span>
                        </div>

                        <div class="contenedorSobreNosotrosFooter sobreNosotrosFooter">
                            <span class="textoSobreNosotros">Sobre Nosotros</span>
                            <ul>
                                <li><a href="#">Inicio</a></li>
                                <li><a href="#portafolio">Portafolio</a></li>
                                <li><a href="#sobreNosotros">Nosotros</a></li>
                                <li><a href="">Tienda</a></li>
                                <li><a href="#horarios">Citas</a></li>
                            </ul>
                        </div>

                        <div class="contenedorSobreNosotrosFooter contenedorRedesFooter">

                            <span>Redes</span>

                            <ul>


                                <li>
                                    <a href="https://www.facebook.com/Tattoolestudiodearte/" target="_blank">
                                        Faceboock
                                        <img src="./imagenes/iconos/facebook.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a href="https://wa.me/5930987270403?text=Deseo obtner más informacion sobre su estudio" target="_blank">
                                        Whatsapp
                                        <img src="./imagenes/iconos/whatsapp.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a href="">
                                        Instagram
                                        <img src="./imagenes/iconos/instagram.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a href="">
                                        Youtube
                                        <img src="./imagenes/iconos/youtube.png" alt="">
                                    </a>
                                </li>

                            </ul>

                        </div>
                    </div>


                    <hr>

                    <div class="contenedorMiMarca">
                        ©
                        <b id="fechaMiMarca"></b>
                        &nbsp By: &nbsp Aaron Reyes &nbsp -> &nbsp
                        <a href="#"> www.aaronreyes.com </a>
                        <img src="./imagenes/iconos/estrella1.png" alt="">
                    </div>

                </footer>

            </div>


        </main>



    </div>




    <!-- Js  Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

    <script src="./validacionFormularioBoostrap.js"></script>


    <!-- js animacion -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>

    <script src="logicaHeader.js"></script>


    <script>
        // IR A #
        const irAbajo = e => {
            window.location.href = `#${e}`
        }

        // IR A WHASTAPP
        const enviarWhatsapp = (mensaje, precio) => {
            window.open(`https://wa.me/593987270403?text=Deseo adquirir el producto '${mensaje}' con el precio de $${precio} dolares`, '_blank')
        }


        // retorna la url de un background image (se pasa el por parametro el id del div que tiene el fondo)
        function getBackgroundImageUrl(element) {

            // sacamos el backgroundImage de el div
            const computedStyle = window.getComputedStyle(element);
            const backgroundImage = computedStyle.backgroundImage;


            // Comprobamos si el fondo tiene una URL
            const urlMatch = backgroundImage.match(/url\("?(.+?)"?\)/);

            if (urlMatch && urlMatch[1]) {

                // desctivar scroll

                // Guarda la posición actual de scroll en las variables
                var x = window.scrollX;
                var y = window.scrollY;

                // Desactiva el scroll estableciendo el scroll a la posición actual
                window.onscroll = function() {
                    window.scrollTo(x, y);
                };


                // retorna la url de la imagen
                return urlMatch[1];


            }

            // si no hay url no retorna nada (null)
            return null;
        }



        // mostar  modal con la imagen
        function mostrarImagen(div) {

            const contenedorModal = document.getElementById('contenedorModal');
            const modalImagen = document.getElementById('modalImagen');
            const miDiv = document.getElementById(`${div}`);
            const backgroundImageUrl = getBackgroundImageUrl(miDiv);

            // si la funcion es exitosa
            if (backgroundImageUrl) {

                // añadimos la una clase para que se muestre el modal
                contenedorModal.classList.add('contenedorModal')
                modalImagen.src = backgroundImageUrl

            } else {
                console.log("El div no tiene una background-image con URL.");
            }
        }


        // Cerrar el modal
        function cerrarModal() {

            // quitamos la clase del modal
            const contenedorModal = document.getElementById('contenedorModal');
            contenedorModal.classList.remove('contenedorModal')

            // hacemos que el scroll funcione de nuevo
            window.onscroll = null;
        }






        // FECHA ACTUAL MI MARCA
        let fechaMiMarca = document.getElementById('fechaMiMarca')
        let year = new Date()
        fechaMiMarca.innerHTML = year.getFullYear()
    </script>
</body>

</html>