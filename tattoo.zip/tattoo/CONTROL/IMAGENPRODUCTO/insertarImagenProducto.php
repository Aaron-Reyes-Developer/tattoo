<?php

///////////////////////// TODA LA LOGICA DE INSERTAR EL PRODUCTO ESTA AQUI

session_start();

if (empty($_SESSION['entrar'])) {
    header('Location: ../../index.php');
    die();
}


include('../../conexion.php');


$respuesta = array('mensaje' => 'entra');

if (
    $_POST['nombre'] == '' ||
    $_POST['descripcion'] == '' ||
    $_POST['precio'] == '' ||
    empty($_FILES['imagen'])
) {
    $respuesta['mensaje'] = 'Datos vacios';
    echo json_encode($respuesta);
    die();
}

// DATOS
$imagen = $_FILES['imagen'];
$sizeImagenKb = $imagen['size'] / 1000;

// si la imagen pesa mas de 1mb
if ($sizeImagenKb > 1000) {
    $respuesta['mensaje'] = 'Imagen muy pesada';
    echo json_encode($respuesta);
    die();
}

$datosImagen = file_get_contents($imagen['tmp_name']);
$imagenBd = $conn->real_escape_string($datosImagen);
$nombre = htmlspecialchars($_POST['nombre']);
$descripcion = htmlspecialchars($_POST['descripcion']);
$precio = $_POST['precio'];
$categoriaProducto = $_POST['categoriaProducto'];






$insertarDatos = mysqli_query($conn, "INSERT INTO productos (imagen,size,nombre, descripcion, precio, fk_id_categoria_producto) VALUES ('$imagenBd','$sizeImagenKb','$nombre','$descripcion','$precio',$categoriaProducto) ");
while (mysqli_next_result($conn)) {;
}


$queryConsulta = mysqli_query($conn, "SELECT * FROM productos WHERE nombre = '$nombre' AND descripcion = '$descripcion' AND precio = '$precio' ");
$recorrerDatos = mysqli_fetch_array($queryConsulta);
$id = $recorrerDatos['id_producto'];


if ($insertarDatos) {
    $respuesta['mensaje'] = 'Datos guardados';
    $respuesta['id'] = $id;
}

$respuesta['size'] = $sizeImagenKb;
echo json_encode($respuesta);
