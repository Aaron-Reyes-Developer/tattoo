<?php

///////////////// TODA LA LOGICA DE EDITAR PRODUCTO



session_start();
if (empty($_SESSION['entrar'])) {
    header('Location: ../../index.php');
    die();
}

include('../../conexion.php');

$mensaje = array('mensaje' => 'Estamos dentro');

// DETECTAR SI LOS DATOS VIENEN VACIOS
if (
    $_POST['tituloTattoo'] == '' ||
    $_POST['descripcionTattoo'] == '' ||
    $_POST['precioTattoo'] == '' ||
    $_POST['categoriaProducto'] == ''
) {

    $mensaje['mensaje'] = 'Datos vacios';
    echo json_encode($mensaje);
    die();
}


// OBTENER DATOS
$id_producto = $_POST['id'];
$titulo = htmlspecialchars($_POST['tituloTattoo']);
$descripcionTattoo = htmlspecialchars($_POST['descripcionTattoo']);
$precioTattoo = htmlspecialchars($_POST['precioTattoo']);
$categoriaProducto = htmlspecialchars($_POST['categoriaProducto']);



// si existe la imagen
if (isset($_FILES['imagen'])) {

    // datos imagen
    $imagenSinFiltro = $_FILES['imagen'];
    $sizeImagen = $imagenSinFiltro['size'];
    $nombreImagen = $imagenSinFiltro['name'];
    $rutaTemporalImagen = $imagenSinFiltro['tmp_name'];
    $datosImagen = file_get_contents($rutaTemporalImagen);
    $imagenBd = $conn->real_escape_string($datosImagen);
    $imagenKb = $sizeImagen / 1000;

    if ($imagenKb >= 1000) {
        $mensaje['mensaje'] = 'Imagen Pesada';
        echo json_encode($mensaje);
        die();
    }




    $queryInsertarDatos = mysqli_query($conn, "UPDATE `productos` 
                                                SET `imagen` = '$imagenBd',
                                                `size` = '$imagenKb' ,
                                                `nombre` = '$titulo', 
                                                `descripcion` = '$descripcionTattoo' ,
                                                `precio` = '$precioTattoo', 
                                                `fecha` = current_timestamp(),
                                                `fk_id_categoria_producto` = '$categoriaProducto'
                                                WHERE `productos`.`id_producto` = $id_producto ");

    if ($queryInsertarDatos) {
        $mensaje['mensaje'] = 'Editados Correctamente';
    } else {
        $mensaje['mensaje'] = 'Algo salio mal';
    }
} else {


    // si no se edita la imagen
    $queryInsertarDatos = mysqli_query($conn, "UPDATE `productos` 
                                                SET `nombre` = '$titulo', 
                                                `descripcion` = '$descripcionTattoo' ,
                                                `precio` = '$precioTattoo', 
                                                `fecha` = current_timestamp(),
                                                `fk_id_categoria_producto` = '$categoriaProducto'
                                                WHERE `productos`.`id_producto` = $id_producto ");

    if ($queryInsertarDatos) {
        $mensaje['mensaje'] = 'Editados Correctamente';
    } else {
        $mensaje['mensaje'] = 'Algo salio mal';
    }
}


echo json_encode($mensaje);
