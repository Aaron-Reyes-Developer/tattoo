<?php

if (isset($_POST['id_imagen'])) {

    $id_imagen = $_POST['id_imagen'];

    $queryEliminar = "DELETE FROM imagenes_tatuajes WHERE id_imagenes_tatuajes = '$id_imagen'";

    if ($queryEliminar) {
        echo json_encode(array('mensaje' => 'ok'));
    }
} else {
    echo "No puedes estar aqui";
}
