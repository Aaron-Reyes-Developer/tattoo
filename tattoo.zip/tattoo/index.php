<?php
include('./conexion.php');


?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0C0C0C">
    <link rel="icon" type="image/png" href="./imagenes/logoTattoo.ico">
    <meta name="description" content="Explora nuestra galería de tatuajes impresionantes y creativos. Desde tatuajes en blanco y negro hasta diseños vibrantes de estilo acuarela, tenemos opciones para todos los gustos. Nuestros artistas del tatuaje expertos te ayudarán a transformar tu visión en arte corporal único. ¡Reserva tu cita hoy para obtener el tatuaje de tus sueños!">


    <!-- Fuente Dosis -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">


    <!-- animacion -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <link rel="stylesheet" href="estiloIndex.css">
    <link rel="stylesheet" href="defecto.css">
    <link rel="stylesheet" href="estiloHeader.css">

    <title>Cierva Ink</title>
</head>

<body>

    <div class="page">


        <header class="header" id="header">

            <div class="contenedorLogo" id="contenedorLogo"> <a> <img src="./imagenes/logoTattoo.webp" alt="" title="logo empresa"> </a> </div>

            <nav class="nav" id="nav">
                <ul>
                    <li id="liNav" class="active"><a href="./index.php">Inicio</a> </li>
                    <li id="liNav" id="nosotrps"><a href="#sobreNosotros">Nosotros</a> </li>
                    <li id="liNav"><a href="./VERTODO/VERTODOPRODUCTO/vertodoProducto.php">Tienda</a> </li>
                    <li id="liNav"><a href="#horarios">Citas</a> </li>
                    <li id="liNav"><a href="#contacto">Contacto</a> </li>
                    <li id="cotizar liNav">
                        <a href="https://wa.me/<?php echo $telefono ?>?text=Deseo cotizar un tatuaje en su estudio" target="_blank">
                            Cotizar
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="contenedorBar" id="bar" onclick="barFuncion()">
                <img src="./imagenes/iconos/bar.png" alt="" id="imagenBar">
                <img src="./imagenes/iconos/close.png" alt="" id="imagenBarClose" style="display: none;">
            </div>

        </header>

        <main>

            <div class="contenedorIrArriba" id="flechaIrArriba">
                <img src="./imagenes/iconos/flechaArriba.png" alt="">
            </div>


            <!-- PORTADA -->
            <div class="contenedorPortada" data-aos="fade-up">

                <h1> CIERVA INK • ESTUDIO </h1>
                <span>
                    Empresa de tatuajes experta en el <b> <strong>Arte</strong> <strong>Corporal</strong> </b>
                </span>

                <div class="rombo" id="rombo" onclick="irAbajo('portafolio')"></div>

            </div>


            <!-- PORTAFOLIO -->
            <section class="seccionPortafolio container" id="portafolio">

                <div class="contenedorTituloPortafolio">
                    <h2>PORTAFOLIO</h2>
                    <a href="./VERTODO/verTodo.php">Ver todo...</a>
                </div>

                <div class="grid">

                    <?php

                    // mostrar fotos
                    $queryMostrarFotos = mysqli_query($conn, "SELECT 
                    im_ta.imagen, 
                    im_ta.fk_id_datos_tattoo,
                    dat_ta.nombre
                    FROM imagenes_tatuajes im_ta
                    INNER JOIN datos_tattoo dat_ta
                    ON dat_ta.id_datos_tattoo = im_ta.fk_id_datos_tattoo
                    WHERE dat_ta.en_cabecera = 1
                    GROUP BY dat_ta.id_datos_tattoo
                    ORDER BY dat_ta.fecha_tattoo DESC LIMIT 8 ");

                    // mostrar las fotos
                    while ($recorrerFotos = mysqli_fetch_array($queryMostrarFotos)) {
                    ?>

                        <div class="cartaPortafolio" data-aos="fade-up">
                            <a href="./DETALLE/detalleTattoo.php?tattoo=<?php echo $recorrerFotos['fk_id_datos_tattoo'] ?>">
                                <img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($recorrerFotos['imagen']) ?>" alt="<?php echo $recorrerFotos['nombre'] ?>">
                            </a>
                        </div>
                    <?php
                    }

                    ?>





                </div>

            </section>


            <!-- SOBRE NOSOTROS -->
            <section class="seccionSobreNosotros container" id="sobreNosotros" data-aos="fade-up">

                <h2>SOBRE NOSOTROS</h2>

                <div class="contenedorTextoMaps">


                    <div class="contenedorTexto">
                        <p>
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores nam nulla assumenda, iure
                            soluta aspernatur, ipsam facere, expedita reprehenderit ratione omnis labore quia? Atque eum
                            ipsam vitae molestiae necessitatibus aut!
                        </p>

                        <button>Agendar Cita</button>
                    </div>


                    <div class="contenedorMaps">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3989.273686800299!2d-80.7334071!3d-0.9467127!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x902be16d63dde979%3A0x583a86515baaa7ec!2sCierva%20Ink%20Tattoo!5e0!3m2!1ses!2sec!4v1698208800217!5m2!1ses!2sec" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>



                </div>


            </section>


            <!-- ESPECIALIDADES -->
            <section class="seccionEspecialidades" id="especialidades" data-aos="fade-up">

                <div class="contenedorEspecialidades container">

                    <h2>ESPECIALIDADES</h2>

                    <div class="subContenedorEspecialidades">


                        <div class="contenedorIconosEspecialidades">
                            <img src="./imagenes/maquina-de-tatuar.webp" alt="Maquina de tatuar icono">
                            <img src="./imagenes/perforacion.webp" alt="Perforacion Icono">
                            <img src="./imagenes/tienda.webp" alt="Tienda icono">
                        </div>


                        <div class="conetenedorListaEspecialidades">
                            <?php
                            $queryEspecialidades = mysqli_query($conn, "SELECT * FROM especialidad");
                            $recorrerEspecialidad = mysqli_fetch_array($queryEspecialidades);
                            ?>
                            <p><?php echo $recorrerEspecialidad['parrafo'] ?></p>
                            <ul>
                                <li><strong><?php echo $recorrerEspecialidad['especialidad_1'] ?></strong></li>
                                <li><strong><?php echo $recorrerEspecialidad['especialidad_2'] ?></strong></li>
                                <li><strong><?php echo $recorrerEspecialidad['especialidad_3'] ?></strong></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </section>


            <!-- HORARIOS DE ATENCION -->
            <section class="seccionHorario container" id="horarios" data-aos="fade-up">

                <h2>HORARIOS DE ATENCIÓN</h2>

                <div class="subcontenedorHorarios">
                    <?php
                    $queryHorario = mysqli_query($conn, "SELECT * FROM horario");
                    $recorrerHorario = mysqli_fetch_array($queryHorario);
                    ?>

                    <ul>
                        <li>Lunes: <?php echo $recorrerHorario['lunes'] ?> </li>
                        <li>Martes: <?php echo $recorrerHorario['martes'] ?> </li>
                        <li>Miercoles: <?php echo $recorrerHorario['miercoles'] ?> </li>
                        <li>Jueves: <?php echo $recorrerHorario['jueves'] ?> </li>
                        <li>Viernes: <?php echo $recorrerHorario['viernes'] ?> </li>
                        <li>Sabado: <?php echo $recorrerHorario['sabado'] ?> </li>
                        <li style="color: rgb(255, 88, 88);"><?php echo $recorrerHorario['domingo'] ?></li>
                    </ul>



                    <div class="contenedorAgendarCita">
                        <a href="https://wa.me/<?php echo $telefono ?>?text=Deseo cotizar un tatuaje en su estudio" target="_blank">Cotizar <img src="./imagenes/iconos/whatsappAdquirir.png" width="15px" alt=""></a>
                    </div>
                </div>

            </section>


            <!-- PRODUCTOS -->
            <section class="seccionProductos container" data-aos="fade-up">

                <div class="contenTituloProducto">
                    <h2>PRODUCTOS</h2>
                    <a href="./VERTODO/VERTODOPRODUCTO/vertodoProducto.php">Ver todo...</a>
                </div>


                <div class="contenedorProductos">

                    <?php
                    $queryProducto = mysqli_query($conn, "SELECT * FROM productos ORDER BY fecha DESC LIMIT 4");

                    while ($recorrerProductos = mysqli_fetch_array($queryProducto)) {

                    ?>
                        <div class="cartaProducto">

                            <a href="./DETALLE/DETALLEPRODUCTO/detalleProducto.php?producto=<?php echo $recorrerProductos['id_producto'] ?>" class="contenedorImagenProducto"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($recorrerProductos['imagen']) ?>" alt="<?php echo $recorrerProductos['nombre'] ?>"></a>

                            <div class="contenedorTextoProducto">

                                <div class="contenedorTituloProducto">
                                    <span><?php echo $recorrerProductos['nombre'] ?></span>
                                    <span class="precio">$<?php echo $recorrerProductos['precio'] ?></span>
                                </div>

                                <button onclick="enviarWhatsapp('<?php echo $recorrerProductos['nombre'] ?>','<?php echo $recorrerProductos['precio'] ?>')">Adquirir <img src="./imagenes/iconos/whatsappAdquirir.png" alt="" width="18px"></button>
                            </div>
                        </div>

                    <?php

                    }

                    ?>

                </div>


            </section>


            <!-- ESTADISTICAS -->
            <section class="seccionEstadistica ">

                <div class="contenedorEstadistica container">

                    <div class="anosExperiencia  subContenedorEstadistica">
                        <span class="numeroExperiencia numeroEstadistica" id="anosExperiencia"></span>
                        <span class="textoExperiencia textoEstadistica">Años de experiencia</span>
                    </div>


                    <div class="clientesAtendido subContenedorEstadistica">
                        <span class="numeroAtendido numeroEstadistica">>50</span>
                        <span class="textoAtendido textoEstadistica">Clientes atendidos </span>
                    </div>


                    <div class="colaboradores subContenedorEstadistica">
                        <span class="numeroColaboradores numeroEstadistica">4</span>
                        <span class="textoColaboradores textoEstadistica">Colaboradores</span>
                    </div>
                </div>

            </section>


            <!-- COLABORADORES -->
            <section class="seccionColaboradores container">


                <h2>COLABORADORES</h2>

                <div class="contenedorColaboradorGrid">


                    <div class="colaborador">
                        <div class="contenedorImagenColaborador"><img src="https://imagenes.elpais.com/resizer/6zpje8PQ5sGMj4kx-45mAMrkU2c=/1200x0/cloudfront-eu-central-1.images.arcpublishing.com/prisa/I4PZI3PSQBEX7JBAKXFS35BJZE.jpg" alt="Foto persona Tatuando"></div>
                        <hr>
                        <span class="nombreColaborador">Aaron Reyes</span>
                        <p class="fraseColaborador">
                            Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Voluptatibus eaque,
                            sequi sit esse earum facere.
                        </p>
                    </div>


                    <div class="colaborador">
                        <div class="contenedorImagenColaborador"><img src="https://previews.123rf.com/images/avistock/avistock2103/avistock210300162/166079582-maestro-de-tatuajes-masculinos-sonriendo-tatuando-a-una-clienta-m%C3%A1quina-de-tatuaje-y-l%C3%A1mpara.jpg" alt="Foto persona Tatuando"></div>
                        <hr>
                        <span class="nombreColaborador">Aaron Reyes</span>
                        <p class="fraseColaborador">
                            Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Voluptatibus eaque,
                            sequi sit esse earum facere.
                        </p>
                    </div>


                    <div class="colaborador">
                        <div class="contenedorImagenColaborador"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgiEQ6D0hxYbleNQKYxlb-lBdJIYbWNKyOQA&usqp=CAU" alt="Foto persona Tatuando"></div>
                        <hr>
                        <span class="nombreColaborador">Aaron Reyes</span>
                        <p class="fraseColaborador">
                            Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Voluptatibus eaque,
                            sequi sit esse earum facere.
                        </p>
                    </div>
                </div>

            </section>


            <!-- RESEÑAS -->
            <section class="seccionResena container">

                <h2>RESEÑAS</h2>
                <span class="textoAlternativo">( Comentarios tomados de 'Google maps' )</span>


                <div class="contenedorResenas">

                    <!-- CARTA 1 -->
                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/ALV-UjWL0bQiAWxI5gb2zr-s7h3PC0DP4kj8jw06NBOlYW1mgw=w60-h60-p-rp-mo-br100" alt=""> </div>
                            <span class="nombre">catalina Gonzalez serna</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>
                                "Un lugar con una excelente vibra , bryan Fuquen un súper artista me ayudó muchísimo en el diseño de mi tatuaje ... Fue perfecto , muy profesional trazos impecables y cierva 🐶 Hermosa !!!!
                                Gracias sin duda volveré pronto.…"
                            </span>
                        </div>

                        <a href="https://maps.app.goo.gl/Hko4XmXeiYP5Qwz19" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                    <!-- CARTA 2 -->
                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/ALV-UjX9Ow7HnImCfbVMxAmhwM4DFmLSiI8-fcVBDqv1CXpMgQ=w60-h60-p-rp-mo-br100" alt=""> </div>
                            <span class="nombre">Evelyn Jaramillo</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>
                                "Muy buena experiencia, lo recomiendo 100 %,el ambiente es super cómodo,
                                relajado y perfecto, cuenta con todo lo necesario; la atención que
                                brindan es muy buena, el artista muy dedicado y minucioso se lo agradezco
                                millón me encantó su trabajo."
                            </span>
                        </div>

                        <a href="https://maps.app.goo.gl/nAX2GF8Kx6wNWayZ6" class="verResena" target="_blank">Ver reseña...</a>

                    </div>

                    <!-- CARTA 3 -->
                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/ALV-UjUKyUw9OFjg0apbsbfAiZuiRbSo6betj4oz37WatPGKMg=w60-h60-p-rp-mo-br100" alt=""> </div>
                            <span class="nombre">Camila Macias Alava</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>
                                "Me encantó el lugar , el servicio y la elaboración de los tatuajes 🥰!!! Muy delicados.
                                El piercing muy chevere y con todos los cuidados necesarios. Ame hacerme mi primer tatuaje con ellos!"
                            </span>
                        </div>

                        <a href="https://maps.app.goo.gl/eRHUKLjq2RzNaiAm6" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                    <!-- CARTA 4 -->
                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/ALV-UjW0v9ajNSfH8sMTOjMB2C802gMLpLRP1Xg8Of-1EmMI2Ns=w60-h60-p-rp-mo-br100" alt=""> </div>
                            <span class="nombre">Belkys juliana Mero espinoza</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>
                                "Muy buena atención y tatúa muy lindo"
                            </span>
                        </div>

                        <a href="https://maps.app.goo.gl/6vQyQSRjAmdib7B86" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                    <!-- CARTA 5 -->
                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a/ACg8ocLpt7hdChs4ANzqenuB8mVxYqcTAKl5r6IoRBjBA3Du=w36-h36-p-rp-mo-br100" alt=""> </div>
                            <span class="nombre">MARIA ALEJANDRA PINTO CASTILLO</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>
                                "Son maravillosos!
                                Bryan y James son artistas maravillosos,
                                captan tu idea en un segundo, y los acabados
                                de sus tatuajes son de otro mundo! Volvería
                                una y otra vez a tatuarme con ellos 😊🎉"
                            </span>
                        </div>

                        <a href="https://maps.app.goo.gl/5LLyjq6W6LJGcj8r8" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                    <!-- CARTA 6 -->
                    <div class="cartaResena" data-aos="fade-up">

                        <div class="contenedorImagenNombre">
                            <div class="contenedorImagen"> <img src="https://lh3.googleusercontent.com/a-/ALV-UjX0ZBPqPMLZpNskLNUqw4uqRf6dwIgL2S5E4lvf11rhvzI=w60-h60-p-rp-mo-br100" alt=""> </div>
                            <span class="nombre">Mario Navia</span>
                        </div>

                        <div class="contenedorComentario">
                            <span>
                                "Excelente trabajo,Bryan eres un excelente artista,muy recomendados gracias por todo,el local impecable."
                            </span>
                        </div>

                        <a href="https://maps.app.goo.gl/RmB9kYG7TTr3uwqu8" class="verResena" target="_blank">Ver reseña...</a>
                    </div>

                </div>


            </section>


            <!-- FOTOS LOCAL -->
            <section class="seccionFotosLocal container" id="seccionFotosLocal">


                <div class="modalDesactivado" id="contenedorModal">
                    <span onclick="cerrarModal()">&times;</span>
                    <img src="https://media.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs" id="modalImagen" alt="Foto local">
                </div>


                <h2>LOCAL</h2>


                <div class="gridLocal">

                    <div class="div1 contenedorImagenLocal" id="div1" onclick="mostrarImagen('div1')"></div>
                    <div class="div2 contenedorImagenLocal" id="div2" onclick="mostrarImagen('div2')"></div>
                    <div class="div3 contenedorImagenLocal" id="div3" onclick="mostrarImagen('div3')"></div>
                    <div class="div4 contenedorImagenLocal" id="div4" onclick="mostrarImagen('div4')"></div>
                    <div class="div5 contenedorImagenLocal" id="div5" onclick="mostrarImagen('div5')"></div>
                    <div class="div6 contenedorImagenLocal" id="div6" onclick="mostrarImagen('div6')"></div>
                    <div class="div7 contenedorImagenLocal" id="div7" onclick="mostrarImagen('div7')"></div>
                    <div class="div8 contenedorImagenLocal" id="div8" onclick="mostrarImagen('div8')"></div>

                </div>


            </section>

            <!-- SECCION CONTACTO -->
            <section class="seccionContacto container" id="contacto" data-aos="fade-up">

                <h2>CONTÁCTANOS</h2>


                <div class="contenedorContactanos">


                    <div class="contenedorFormulario">


                        <form id="formularioContacto" class="formulario ">

                            <h3>Contáctanos</h3>

                            <div class="form-floating mb-3 has-validation">
                                <input type="text" name="nombre" class="form-control" id="nombre" placeholder="Nombre y Apellido" required>
                                <label for="nombre">Nombre y Apellido</label>
                            </div>



                            <div class="form-floating mb-3">
                                <input type="email" name="correo" class="form-control" id="correo" placeholder="correo@ejemplo.com" required>
                                <label for="correo">Correo Electronico</label>
                            </div>

                            <div class="form-floating">
                                <textarea class="form-control" placeholder="Mensaje" id="mensaje" name="mensaje" style="height: 100px" required></textarea>
                                <label for="mensaje">Mensaje</label>
                            </div>

                            <input type="submit" value="Enviar" class="botonEnviar">
                        </form>

                    </div>




                    <div class="contenedorImagenFormulario">
                        <img src="./imagenes/contacto.webp" alt="">
                    </div>
                </div>


            </section>


            <!-- FOOTER -->
            <div class="contenedorMainFooter" data-aos="fade-up">

                <div style="height: 150px; overflow: hidden;">
                    <svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;">
                        <path d="M-84.08,154.45 C149.99,150.00 467.27,63.66 515.79,169.25 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #303030;"></path>
                    </svg>
                </div>


                <footer class="footer" id="footer">

                    <div class="contenedorFooter">

                        <div class="contenedorLogoFooter">
                            <img src="./imagenes/logoTattoo.webp" alt="">
                            <span>CIERVA INK</span>
                        </div>

                        <div class="contenedorSobreNosotrosFooter sobreNosotrosFooter">
                            <span class="textoSobreNosotros">Sobre Nosotros</span>
                            <ul>
                                <li><a href="./index.php">Inicio</a></li>
                                <li><a href="#portafolio">Portafolio</a></li>
                                <li><a href="#sobreNosotros">Nosotros</a></li>
                                <li><a href="./VERTODO/VERTODOPRODUCTO/vertodoProducto.php">Tienda</a></li>
                                <li><a href="#horarios">Citas</a></li>
                            </ul>
                        </div>

                        <div class="contenedorSobreNosotrosFooter contenedorRedesFooter">

                            <span>Redes</span>

                            <ul>


                                <li>
                                    <a href="https://www.facebook.com/Tattoolestudiodearte/" target="_blank">
                                        Faceboock
                                        <img src="./imagenes/iconos/facebook.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a href="https://wa.me/<?php echo $telefono ?>?text=Deseo obtener más informacion sobre su estudio" target="_blank">
                                        Whatsapp
                                        <img src="./imagenes/iconos/whatsapp.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a target="_blank" href="https://www.instagram.com/ciervaink.estudio/">
                                        Instagram
                                        <img src="./imagenes/iconos/instagram.png" alt="">
                                    </a>
                                </li>


                                <li>
                                    <a href="">
                                        Youtube
                                        <img src="./imagenes/iconos/youtube.png" alt="">
                                    </a>
                                </li>

                            </ul>

                        </div>
                    </div>


                    <hr>

                    <div class="contenedorMiMarca">
                        ©
                        <b id="fechaMiMarca"></b>
                        &nbsp By: &nbsp Aaron Reyes &nbsp -> &nbsp
                        <a href="#"> www.aaronreyes.com </a>
                        <img src="./imagenes/iconos/estrella1.png" alt="">
                    </div>

                </footer>

            </div>


        </main>



    </div>




    <!-- Js  Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>


    <!-- js animacion -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>

    <script src="logicaHeader.js"></script>

    <!-- ALERTA PERSONALIZADA -->
    <script src="./alertaPersonalizada.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <script>
        // IR A #
        const irAbajo = e => {
            window.location.href = `#${e}`
        }

        // IR A WHASTAPP
        const enviarWhatsapp = (mensaje, precio) => {
            window.open(`https://wa.me/<?php echo $telefono ?>?text=Deseo adquirir el producto '${mensaje}'`, '_blank')
        }

        // pinta los años de experiencia que tiene el local
        idDiv = document.getElementById('anosExperiencia')
        date = new Date().getFullYear()
        idDiv.innerHTML = date - 2015



        // retorna la url de un background image del css (usado para las fotos del local) (se pasa el por parametro el id del div que tiene el fondo)
        function getBackgroundImageUrl(element) {

            // sacamos el backgroundImage de el div
            const computedStyle = window.getComputedStyle(element);
            const backgroundImage = computedStyle.backgroundImage;


            // Comprobamos si el fondo tiene una URL
            const urlMatch = backgroundImage.match(/url\("?(.+?)"?\)/);

            if (urlMatch && urlMatch[1]) {

                // desctivar scroll

                // Guarda la posición actual de scroll en las variables
                var x = window.scrollX;
                var y = window.scrollY;

                // Desactiva el scroll estableciendo el scroll a la posición actual
                window.onscroll = function() {
                    window.scrollTo(x, y);
                };


                // retorna la url de la imagen
                return urlMatch[1];


            }

            // si no hay url no retorna nada (null)
            return null;
        }



        // mostar  modal con la imagen en fotos local
        function mostrarImagen(div) {

            const contenedorModal = document.getElementById('contenedorModal');
            const modalImagen = document.getElementById('modalImagen');
            const miDiv = document.getElementById(`${div}`);
            const backgroundImageUrl = getBackgroundImageUrl(miDiv);

            // si la funcion es exitosa
            if (backgroundImageUrl) {

                // añadimos la una clase para que se muestre el modal
                contenedorModal.classList.add('contenedorModal')
                modalImagen.src = backgroundImageUrl

            } else {
                console.log("El div no tiene una background-image con URL.");
            }
        }


        // Cerrar el modal
        function cerrarModal() {

            // quitamos la clase del modal
            const contenedorModal = document.getElementById('contenedorModal');
            contenedorModal.classList.remove('contenedorModal')

            // hacemos que el scroll funcione de nuevo
            window.onscroll = null;
        }



        //////////////////      FUNCIONALIDAD CONTACTO      //////////////////
        var formularioContacto = document.getElementById('formularioContacto')



        formularioContacto.addEventListener('submit', function(e) {
            e.preventDefault()

            let formdata = new FormData(formularioContacto)

            if (formdata.get('nombre') == '' || formdata.get('correo') == '' || formdata.get('mensaje') == '') {

                alert('datos vacios')
                return
            }


            fetch('./CONTROL/CONTACTO/insertarContacto.php', {
                    method: 'POST',
                    body: formdata
                })
                .then(res => res.json())
                .then(e => {

                    if (e.mensaje === 'error bd') {
                        alertaPersonalizada('CORRECTO', 'Algo salio mal :( .', 'error', 'Regresar', 'no')
                        return
                    }


                    if (e.mensaje === 'ok') {
                        alertaPersonalizada('CORRECTO', 'Enviado Correctamente, nos pondremos en contacto contigo lo más antes posible.', 'success', 'Regresar', 'no')

                        document.getElementById('nombre').value = ''
                        document.getElementById('correo').value = ''
                        document.getElementById('mensaje').value = ''
                    }
                })


        })










        // FECHA ACTUAL MI MARCA
        let fechaMiMarca = document.getElementById('fechaMiMarca')
        let year = new Date()
        fechaMiMarca.innerHTML = year.getFullYear()
    </script>
</body>

</html>